# R8-C 结果：真实 Shikigami（研究副本）→ 计量代理 → Mock Provider

日期：2026-11-21 23:0x（Asia/Shanghai）
方式：完整复制 `runtime/shikigami` 到研究目录，**只改副本的 `config/app.yaml`**（`base_url` → `http://127.0.0.1:7791/v1`，`model` → `mock-model`），
生产配置与生产进程**零改动**。未联网、未使用真实 Key。

## 运行命令

```powershell
D:\SoulMate\runtime\venv\Scripts\python.exe D:\SoulMate_Research\R8\poc\run_r8c.py
```

## 结果：7/7 通过

```
Shikigami 副本已就绪 127.0.0.1:7798
  example_luna: 1.02s len=16 '你好，这是一条 mock 回复。'
  example_luna_en: 0.33s len=16 '你好，这是一条 mock 回复。'
  example_mochi: 0.19s len=16 '你好，这是一条 mock 回复。'
  example_mochi_en: 0.27s len=16 '你好，这是一条 mock 回复。'
PASS 1 四个 persona 全部返回内容
PASS 2 用量被代理记录  [rows=7]
PASS 3 每条都有 exact usage  [exact=7]
PASS 4 token 数来自 final chunk
PASS 5 归因为 unassigned（M2 预期）
PASS 6 模型名与 preset 一致  [mock-model]
PASS 7 未产生 unknown/incomplete
```

账本（7 行，全部 exact）：

```
exact unassigned model=mock-model in=11 out=7 total=18 status=200   ×7
```

## 三个关键观察

### 1. 代理确实在真实调用链里生效
Shikigami 的 `chat.py` 走 `config.get_active_llm_preset()` → `model_gateway.model_route()` → `base_url/chat/completions`，
副本把 base_url 指向代理后，**每一次上游调用都经过代理并被记账**。

### 2. 4 条消息 → 7 次上游请求
四个 persona 各发一条消息，代理记到 **7 条**。多出来的 3 条是 Shikigami 的后台调用（情绪分类 / 亲密度 / 记忆相关）。
这条数据直接印证了 R8-A 的判断：**"一条用户消息 = 一次模型请求"是错的**，必须逐次上游请求记账。

### 3. 归因仍是 unassigned（M2 生效，也证明缺口真实）
7 行全部 `attribution=unassigned`、`persona_id=NULL`。这不是实现缺陷，而是：
- 代理拿不到 Gateway 的 persona；
- Shikigami 不向 provider 传任何请求级标识（`model_gateway.py:89-96` 白名单过滤）。

## 调试中发现的一个真问题（值得记录）

初版 mock 的 SSE 帧只写了 `data: {...}\n`，**少了帧间空行**。OpenAI SDK 会把连续 data 行合并成一个事件，
导致 JSON 解析失败、Shikigami 报 `empty or error response`。修正为 `\n\n` 后一切正常。

给后续实现的教训：
- 代理本身字节透明（PoC 已证 966B 一致），但**mock 保真度不足会伪装成代理故障**；
- 做兼容性验证时，mock 必须严格遵循 SSE 分帧规范，否则排查方向会被带偏。

## 局限

1. Mock 只返回纯文本，没有 tool_calls；因此没有覆盖 Shikigami 的工具循环路径。
2. 只测了 4 条消息 + 3 次后台调用，没有并发与长会话压力。
3. 没有接真实 DeepSeek：final usage 字段形状仍待 R8-D 用一次受控真实调用确认。
4. 副本运行在桌面 Windows，不等于手机 Termux 环境；R8-C 的结论限于"调用链能穿过代理"，不含手机性能。

---

## 补测（R8.1-P0-03）：每条消息触发的上游请求数**不稳定**

三轮独立测量（同一研究副本、同一 mock、只改发送节奏）：

| 轮次 | 4 条消息触发的上游请求 | 每条分布 |
|---|---|---|
| A | 7 | 1 主 + 若干后台 |
| B | 13 | [3,3,4,3] |
| C | 6 | [3,1,1,1] |

结论：
1. **不存在固定倍率**。"一条消息 = 一次请求"错，"固定 1.75 倍"同样错。
2. 差异来自 agent 路径与后台调用触发时机（情绪/亲密度/记忆阈值、模型是否返回工具调用）。
3. 因此账本必须**逐次上游请求**记录，任何按消息数估算成本的做法都会失真。
4. 后台调用仍无法归属到 persona（无身份传播通道），只能按时间归类 —— 这是 M2 的已知限制，不是实现缺陷。
