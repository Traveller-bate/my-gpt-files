#!/data/data/com.termux/files/usr/bin/python3
"""读取 .env 类文件的 DEEPSEEK 变量，只输出长度与指纹。"""
import hashlib
import re
import sys

for path in sys.argv[1:]:
    try:
        text = open(path, encoding="utf-8", errors="ignore").read()
    except Exception as e:
        print(f"{path}: unreadable ({type(e).__name__})")
        continue
    print(f"== {path}")
    for line in text.splitlines():
        m = re.match(r"^(DEEPSEEK_API_KEY|DEEPSEEKPRO_API_KEY)=(.*)$", line.strip())
        if m:
            v = m.group(2)
            fp = hashlib.sha256(v.encode()).hexdigest()[:12] if v else "-"
            print(f"   {m.group(1)} len={len(v)} sha256[:12]={fp}")
