#!/usr/bin/env python3
"""R8-B 计量代理 stub：字节级透传 + usage 捕获 + 账本。

拓扑：client → [本代理 :7791] → mock/provider :7900

关键点（对应 R8-A §3）：
- 按字节搬运，不重组、不延迟；用增量 UTF-8 解码器只做"旁路观察"，不影响转发
- 支持 CRLF/LF、注释帧、[DONE]、任意 chunk 边界
- 记录 usage（final chunk）、上游状态、客户端断开、重启恢复
- 不记录正文/Authorization
"""
from __future__ import annotations

import argparse
import codecs
import json
import sqlite3
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

SCHEMA = """
CREATE TABLE IF NOT EXISTS usage_requests (
  invocation_id TEXT PRIMARY KEY,
  provider TEXT, model TEXT, endpoint TEXT, stream INTEGER,
  attribution TEXT, persona_id TEXT, relation TEXT,
  request_started_at INTEGER, response_finished_at INTEGER,
  upstream_status INTEGER, error_code TEXT,
  input_tokens INTEGER, output_tokens INTEGER, total_tokens INTEGER,
  cache_hit_tokens INTEGER, cache_miss_tokens INTEGER, reasoning_tokens INTEGER,
  usage_status TEXT, status_cause TEXT
);
"""


class Ledger:
    def __init__(self, path: str):
        self.path = path
        self.lock = threading.Lock()
        con = sqlite3.connect(path)
        con.executescript(SCHEMA)
        # 重启恢复：未终结的记录一律 unknown
        con.execute(
            "UPDATE usage_requests SET usage_status='unknown', status_cause='proxy_restart' "
            "WHERE usage_status='open'")
        con.commit()
        con.close()

    def start(self, **kw) -> str:
        iid = kw.pop("invocation_id")
        with self.lock, sqlite3.connect(self.path) as con:
            con.execute(
                "INSERT INTO usage_requests(invocation_id, provider, model, endpoint, stream, attribution,"
                " persona_id, relation, request_started_at, usage_status) VALUES(?,?,?,?,?,?,?,?,?,'open')",
                (iid, kw.get("provider"), kw.get("model"), kw.get("endpoint"), kw.get("stream"),
                 kw.get("attribution", "unassigned"), kw.get("persona_id"), kw.get("relation"),
                 kw.get("started")))
        return iid

    def finish(self, iid: str, **kw):
        with self.lock, sqlite3.connect(self.path) as con:
            con.execute(
                "UPDATE usage_requests SET response_finished_at=?, upstream_status=?, error_code=?,"
                " input_tokens=?, output_tokens=?, total_tokens=?, cache_hit_tokens=?, cache_miss_tokens=?,"
                " reasoning_tokens=?, usage_status=?, status_cause=? WHERE invocation_id=?",
                (kw.get("finished"), kw.get("status"), kw.get("error_code"),
                 kw.get("input_tokens"), kw.get("output_tokens"), kw.get("total_tokens"),
                 kw.get("cache_hit_tokens"), kw.get("cache_miss_tokens"), kw.get("reasoning_tokens"),
                 kw.get("usage_status"), kw.get("status_cause"), iid))


class SseObserver:
    """旁路解析：只观察字节流，不改变转发内容。"""

    def __init__(self):
        self.decoder = codecs.getincrementaldecoder("utf-8")("replace")
        self.buf = ""
        self.usage = None
        self.done = False
        self.events = 0

    def feed(self, chunk: bytes):
        self.buf += self.decoder.decode(chunk)
        # 同时兼容 LF 与 CRLF
        while True:
            idx = self.buf.find("\n")
            if idx < 0:
                break
            line = self.buf[:idx].rstrip("\r")
            self.buf = self.buf[idx + 1:]
            if not line or line.startswith(":"):
                continue
            if line.startswith("data:"):
                payload = line[5:].strip()
                if payload == "[DONE]":
                    self.done = True
                    continue
                self.events += 1
                try:
                    obj = json.loads(payload)
                except Exception:
                    continue
                if isinstance(obj.get("usage"), dict):
                    self.usage = obj["usage"]


def parse_usage(u: dict) -> dict:
    details = u.get("completion_tokens_details") or {}
    return {
        "input_tokens": u.get("prompt_tokens"),
        "output_tokens": u.get("completion_tokens"),
        "total_tokens": u.get("total_tokens"),
        "cache_hit_tokens": u.get("prompt_cache_hit_tokens"),
        "cache_miss_tokens": u.get("prompt_cache_miss_tokens"),
        "reasoning_tokens": details.get("reasoning_tokens"),
    }


class Proxy(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    upstream = None
    ledger: Ledger = None

    def log_message(self, *args):
        pass

    def do_GET(self):
        if self.path.startswith("/healthz"):
            body = b'{"ready":true}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_error(404)

    def do_POST(self):
        import time
        import urllib.request
        import urllib.error

        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            body = json.loads(raw)
        except Exception:
            body = {}
        stream = bool(body.get("stream"))
        iid = str(uuid.uuid4())

        # 归因：本 PoC 显式区分"可归因"（测试注入 header）与"不可归因"
        persona = (self.headers.get("X-SoulMate-Persona") or "").strip() or None
        attribution = "persona" if persona else "unassigned"

        self.ledger.start(invocation_id=iid, provider="mock", model=body.get("model"),
                          endpoint=self.path, stream=1 if stream else 0,
                          attribution=attribution, persona_id=persona, relation="primary",
                          started=int(time.time() * 1000))

        target = self.upstream.rstrip("/") + self.path
        req = urllib.request.Request(target, data=raw, method="POST")
        for h in ("Content-Type", "Authorization", "Accept"):
            if self.headers.get(h):
                req.add_header(h, self.headers[h])
        if self.headers.get("X-Mock-Mode"):
            req.add_header("X-Mock-Mode", self.headers["X-Mock-Mode"])

        try:
            resp = urllib.request.urlopen(req, timeout=30)
        except urllib.error.HTTPError as e:
            err = e.read()
            self.ledger.finish(iid, finished=int(time.time() * 1000), status=e.code,
                               usage_status="unknown", status_cause="upstream_error",
                               error_code=f"http_{e.code}")
            self.send_response(e.code)
            self.send_header("Content-Type", e.headers.get("Content-Type", "application/json"))
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)
            return
        except Exception as e:
            self.ledger.finish(iid, finished=int(time.time() * 1000), usage_status="unknown",
                               status_cause="upstream_unreachable", error_code=type(e).__name__)
            self.send_error(502)
            return

        ctype = resp.headers.get("Content-Type", "application/json")
        self.send_response(resp.status)
        self.send_header("Content-Type", ctype)

        if not stream:
            data = resp.read()
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            usage = None
            try:
                usage = json.loads(data).get("usage")
            except Exception:
                pass
            if usage:
                self.ledger.finish(iid, finished=int(time.time() * 1000), status=resp.status,
                                   usage_status="exact", **parse_usage(usage))
            else:
                self.ledger.finish(iid, finished=int(time.time() * 1000), status=resp.status,
                                   usage_status="unknown", status_cause="no_final_usage")
            return

        self.send_header("Connection", "close")
        self.end_headers()
        obs = SseObserver()
        aborted = False
        try:
            while True:
                chunk = resp.read(64)
                if not chunk:
                    break
                obs.feed(chunk)
                try:
                    self.wfile.write(chunk)
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError):
                    aborted = True
                    break
        finally:
            resp.close()
            finished = int(time.time() * 1000)
            if obs.usage and not aborted:
                self.ledger.finish(iid, finished=finished, status=200, usage_status="exact",
                                   **parse_usage(obs.usage))
            elif obs.usage and aborted:
                self.ledger.finish(iid, finished=finished, status=200, usage_status="exact",
                                   status_cause="client_aborted_after_usage", **parse_usage(obs.usage))
            elif aborted:
                self.ledger.finish(iid, finished=finished, status=200, usage_status="incomplete",
                                   status_cause="client_aborted")
            else:
                self.ledger.finish(iid, finished=finished, status=200, usage_status="unknown",
                                   status_cause="no_final_usage")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=7791)
    ap.add_argument("--upstream", default="http://127.0.0.1:7900")
    ap.add_argument("--db", default="ledger.db")
    args = ap.parse_args()

    Proxy.upstream = args.upstream
    Proxy.ledger = Ledger(args.db)
    srv = ThreadingHTTPServer(("127.0.0.1", args.port), Proxy)
    print(f"metering proxy on 127.0.0.1:{args.port} -> {args.upstream} (db={args.db})", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
