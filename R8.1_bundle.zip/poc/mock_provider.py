#!/usr/bin/env python3
"""R8-B Mock：一个受控的 OpenAI-compatible Provider。

用于验证计量代理，不联网、不用真实 Key。

行为由请求体与路径决定：
  POST /v1/chat/completions  stream=false -> 返回带 usage 的 JSON
  POST /v1/chat/completions  stream=true  -> SSE，最后一个 data 帧带 usage
  特殊开关（通过 header X-Mock-Mode）:
    chunk-split  : 把 SSE 按 7 字节硬切（含 UTF-8 中间）
    crlf         : 用 \r\n 行分隔
    comment      : 每帧前插入 ": keepalive" 注释
    error500     : 直接返回 500 JSON
    slow         : 每个 chunk 间隔 0.05s
"""
from __future__ import annotations

import json
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

USAGE = {
    "prompt_tokens": 11,
    "completion_tokens": 7,
    "total_tokens": 18,
    "prompt_cache_hit_tokens": 3,
    "prompt_cache_miss_tokens": 8,
    "completion_tokens_details": {"reasoning_tokens": 2},
}


def sse_lines(model: str, with_usage: bool = True) -> list[bytes]:
    def data(obj: dict) -> bytes:
        return ("data: " + json.dumps(obj, ensure_ascii=False) + "\n\n").encode()

    frames: list[bytes] = []
    frames.append(data({"id": "chatcmpl-mock", "object": "chat.completion.chunk",
                        "choices": [{"index": 0, "delta": {"role": "assistant"}}]}))
    for piece in ["你好", "，这是", "一条 mock 回复", "。"]:
        frames.append(data({"id": "chatcmpl-mock", "object": "chat.completion.chunk",
                            "choices": [{"index": 0, "delta": {"content": piece}}]}))
    final = {"id": "chatcmpl-mock", "object": "chat.completion.chunk",
             "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}]}
    if with_usage:
        final["usage"] = USAGE
    frames.append(data(final))
    frames.append(b"data: [DONE]\n\n")
    return frames


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):  # 静音
        pass

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            body = json.loads(raw)
        except Exception:
            body = {}
        mode = (self.headers.get("X-Mock-Mode") or "").strip()
        stream = bool(body.get("stream"))

        if mode.startswith("error"):
            try:
                code = int(mode.replace("error", "") or "500")
            except ValueError:
                code = 500
            if code == 401:
                payload = b'{"error":"unauthorized"}'
            elif code == 429:
                payload = b'rate limited by mock'
            else:
                payload = json.dumps({"error": {"message": f"mock upstream failure {code}"}}).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json" if code not in (401, 429) else "text/plain")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if not stream:
            payload = json.dumps({
                "id": "chatcmpl-mock", "object": "chat.completion",
                "choices": [{"index": 0, "message": {"role": "assistant", "content": "非流式 mock 回复"},
                             "finish_reason": "stop"}],
                "usage": USAGE,
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        frames = sse_lines(body.get("model") or "mock-model", with_usage=("no-usage" not in mode))
        if "crlf" in mode:
            frames = [f.replace(b"\n", b"\r\n") for f in frames]
        if "comment" in mode:
            frames = [b": keepalive\n"] + frames
        blob = b"".join(frames)

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()

        if "chunk-split" in mode:
            step = 7
            for i in range(0, len(blob), step):
                try:
                    self.wfile.write(blob[i:i + step])
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError):
                    return
                if "slow" in mode:
                    time.sleep(0.05)
        else:
            for f in frames:
                try:
                    self.wfile.write(f)
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError):
                    return
                if "slow" in mode:
                    time.sleep(0.05)
        self.close_connection = True


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 7900
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"mock provider on 127.0.0.1:{port}", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
