#!/data/data/com.termux/files/usr/bin/python3
"""读取指定 PID 的环境变量，只输出键名与 SHA-256 前 12 位，绝不输出值。"""
import hashlib
import os
import sys

pids = sys.argv[1:] or []
for pid in pids:
    try:
        raw = open(f"/proc/{pid}/environ", "rb").read()
    except Exception as e:
        print(f"PID {pid}: unreadable ({type(e).__name__})")
        continue
    found = False
    for entry in raw.split(b"\0"):
        if not entry or b"=" not in entry:
            continue
        k, v = entry.split(b"=", 1)
        name = k.decode("utf-8", "replace")
        if "DEEPSEEK" in name or name in ("NO_PROXY", "SOULMATE_DIAG"):
            fp = hashlib.sha256(v).hexdigest()[:12] if v else "-"
            print(f"PID {pid} {name} len={len(v)} sha256[:12]={fp}")
            found = True
    if not found:
        print(f"PID {pid}: no DEEPSEEK/NO_PROXY vars")
