#!/usr/bin/env python3
"""R8.1-P0-03（修正版）：4 条消息触发的上游请求统计。

不猜测"哪条后台调用属于哪条消息"——按请求到达代理的时间顺序与间隔分类：
  primary   : 与该条消息请求窗口重叠的调用
  background: 其余紧随其后的调用（间隔 < 5s）
并明确说明：没有身份传播通道，无法把 background 精确归属到某个 persona。
"""
from __future__ import annotations

import json
import os
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
R8 = os.path.dirname(HERE)
COPY = os.path.join(R8, "shikigami_copy")
DB = os.path.join(HERE, "r8c_map.db")
MOCK, PROXY, SHIKI = 7932, 7791, 7804
PERSONAS = ["example_luna", "example_luna_en", "example_mochi", "example_mochi_en"]


def wait_port(port, timeout=90):
    t0 = time.time()
    while time.time() - t0 < timeout:
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", port)) == 0:
                return True
        time.sleep(0.2)
    return False


def chat(persona, text):
    body = json.dumps({"message": text, "session_id": persona, "client_id": "r8c-map2"}).encode()
    req = urllib.request.Request(f"http://127.0.0.1:{SHIKI}/chat", data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    tok, t0 = [], time.time()
    with urllib.request.urlopen(req, timeout=90) as r:
        for raw in r:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            try:
                o = json.loads(line[5:].strip())
            except Exception:
                continue
            if o.get("token"):
                tok.append(o["token"])
            if o.get("done"):
                break
    return "".join(tok), t0, time.time()


def main():
    if os.path.exists(DB):
        os.remove(DB)
    procs = [subprocess.Popen([sys.executable, os.path.join(HERE, "mock_provider.py"), str(MOCK)],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL),
             subprocess.Popen([sys.executable, os.path.join(HERE, "metering_proxy.py"),
                               "--port", str(PROXY), "--upstream", f"http://127.0.0.1:{MOCK}",
                               "--db", DB], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)]
    try:
        if not (wait_port(MOCK) and wait_port(PROXY)):
            print("mock/proxy 未就绪"); return 1
        env = dict(os.environ); env["PYTHONPATH"] = COPY
        procs.append(subprocess.Popen([sys.executable, "-m", "uvicorn", "server:app",
                                       "--host", "127.0.0.1", "--port", str(SHIKI), "--loop", "asyncio"],
                                      cwd=COPY, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        if not wait_port(SHIKI):
            print("Shikigami 未就绪"); return 1

        marks = []
        for p in PERSONAS:
            txt, t0, t1 = chat(p, "用一句话回答：现在几点？")
            marks.append({"persona": p, "t0": t0, "t1": t1, "len": len(txt), "text": txt[:40]})
            print(f"  {p}: {t1-t0:.2f}s len={len(txt)}", flush=True)
            time.sleep(2.0)
        print("等待后台调用落账 12s ...", flush=True)
        time.sleep(12)

        with sqlite3.connect(DB) as con:
            con.row_factory = sqlite3.Row
            rows = [dict(r) for r in con.execute(
                "SELECT invocation_id, request_started_at, response_finished_at, attribution,"
                " usage_status, total_tokens, upstream_status FROM usage_requests"
                " ORDER BY request_started_at")]

        # 分类：与任一消息窗口重叠 = primary；其余 = background
        for r in rows:
            t = r["request_started_at"] / 1000.0
            r["kind"] = "primary" if any(m["t0"] - 0.5 <= t <= m["t1"] + 0.5 for m in marks) else "background"

        prim = [r for r in rows if r["kind"] == "primary"]
        bg = [r for r in rows if r["kind"] == "background"]
        per_msg = []
        for m in marks:
            n = sum(1 for r in rows if m["t0"] - 0.5 <= r["request_started_at"] / 1000.0 <= m["t1"] + 2.0)
            per_msg.append(n)
        print("\n账本（按时间）：")
        for r in rows:
            print(f"  {r['kind']:<11} {r['usage_status']:<9} tokens={r['total_tokens']} "
                  f"inv={r['invocation_id'][:8]}")
        print(f"\n每条消息触发的上游请求数：{per_msg}（合计 {len(rows)}）")
        print("说明：无身份传播通道，紧随主回复的调用只能按时间归类，不能归属到具体 persona（M2 限制）。")

        out = {"messages": marks, "ledger_rows": rows,
               "per_message_counts": per_msg, "total": len(rows),
               "note": "后台/后续调用无法归属 persona"}
        with open(os.path.join(R8, "R8_C_MAPPING.json"), "w", encoding="utf-8") as fh:
            json.dump(out, fh, ensure_ascii=False, indent=2)
        ok = all(n >= 1 for n in per_msg) and len(rows) >= 4
        print("\nRESULT:", "PASS" if ok else "FAIL", f"per_msg={per_msg} total={len(rows)}")
        return 0 if ok else 1
    finally:
        for p in procs:
            p.terminate()
        for p in procs:
            try:
                p.wait(timeout=8)
            except Exception:
                pass


if __name__ == "__main__":
    sys.exit(main())
