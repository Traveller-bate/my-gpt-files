#!/usr/bin/env python3
"""R8.1 扩展测试：覆盖审查书 P0-02 要求的场景。

场景：
 E1 随机 chunk 边界（1..64 字节随机切）
 E2 慢客户端（每 100ms 读 10 字节）
 E3 客户端取消（RST），验证 Provider 端是否被终止
 E4 上游 401 / 402 / 429 / 500（含非 JSON 错误体）
 E5 usage 缺失（final chunk 无 usage）
 E6 代理中途崩溃（kill -9），重启后 open → unknown
 E7 SQLite 写失败（只读库）
 E8 混合：非流式 + 流式 + 后台并发 5 条

输出：每个用例 PASS/FAIL + 原始断言信息；退出码 0 表示全过。
"""
from __future__ import annotations

import json
import os
import random
import socket
import sqlite3
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "ext_ledger.db")
MOCK, PROXY = 7930, 7796
results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if detail else ""), flush=True)


def wait_port(port, timeout=15):
    t0 = time.time()
    while time.time() - t0 < timeout:
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", port)) == 0:
                return True
        time.sleep(0.05)
    return False


def start_mock():
    return subprocess.Popen([sys.executable, os.path.join(HERE, "mock_provider.py"), str(MOCK)],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def start_proxy(db=DB):
    return subprocess.Popen([sys.executable, os.path.join(HERE, "metering_proxy.py"),
                             "--port", str(PROXY), "--upstream", f"http://127.0.0.1:{MOCK}",
                             "--db", db], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def post(body=None, headers=None, timeout=20, path="/v1/chat/completions"):
    body = body or {"model": "mock-model", "messages": [{"role": "user", "content": "hi"}], "stream": True}
    req = urllib.request.Request(f"http://127.0.0.1:{PROXY}{path}",
                                 data=json.dumps(body).encode() if not isinstance(body, bytes) else body,
                                 method="POST")
    req.add_header("Content-Type", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    return urllib.request.urlopen(req, timeout=timeout)


def rows(db=DB):
    if not os.path.exists(db):
        return []
    with sqlite3.connect(db) as con:
        con.row_factory = sqlite3.Row
        return [dict(r) for r in con.execute("SELECT * FROM usage_requests")]


def main():
    for f in (DB, DB + ".ro"):
        if os.path.exists(f):
            os.remove(f)
    mock = start_mock()
    proxy = start_proxy()
    procs = [mock, proxy]
    try:
        assert wait_port(MOCK) and wait_port(PROXY), "services not ready"

        # E1 随机 chunk
        ok_count = 0
        for _ in range(5):
            with post(headers={"X-Mock-Mode": "chunk-split"}) as r:
                data = r.read()
            if b"[DONE]" in data and "一条 mock 回复".encode() in data:
                ok_count += 1
        check("E1 随机/碎片 chunk 边界 5 次一致", ok_count == 5, f"{ok_count}/5")

        # E2 慢客户端
        with post(headers={"X-Mock-Mode": "slow"}) as r:
            buf = b""
            while True:
                chunk = r.read(10)
                if not chunk:
                    break
                buf += chunk
                time.sleep(0.01)
        check("E2 慢客户端仍收完整", b"[DONE]" in buf and len(buf) > 500, f"{len(buf)}B")

        # E3 客户端取消（RST）
        s = socket.create_connection(("127.0.0.1", PROXY))
        body = json.dumps({"model": "mock-model", "messages": [], "stream": True}).encode()
        s.sendall(b"POST /v1/chat/completions HTTP/1.1\r\nHost: x\r\nContent-Type: application/json\r\n"
                  b"X-Mock-Mode: slow\r\n" + f"Content-Length: {len(body)}\r\n\r\n".encode() + body)
        s.recv(64)
        import struct
        s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0))
        s.close()
        time.sleep(0.8)
        r_abort = [x for x in rows() if x["status_cause"] == "client_aborted"]
        check("E3 客户端取消记为 client_aborted", len(r_abort) >= 1, f"n={len(r_abort)}")

        # E4 上游错误码
        for code in ("error500", "error401", "error402", "error429"):
            try:
                with post(headers={"X-Mock-Mode": code}) as r:
                    r.read()
                got = 200
            except urllib.error.HTTPError as e:
                got = e.code
            check(f"E4 上游 {code} 原样透传", got == int(code.replace("error", "")), f"code={got}")

        # E5 usage 缺失
        with post(headers={"X-Mock-Mode": "no-usage"}) as r:
            d5 = r.read()
        r_nousage = [x for x in rows() if x["status_cause"] == "no_final_usage"]
        check("E5 usage 缺失记 unknown", len(r_nousage) >= 1, f"n={len(r_nousage)}")

        # E7 SQLite 只读（先建库再只读打开）
        ro = DB + ".ro"
        if os.path.exists(ro):
            os.remove(ro)
        with sqlite3.connect(ro) as con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS usage_requests (
              invocation_id TEXT PRIMARY KEY, provider TEXT, model TEXT, endpoint TEXT, stream INTEGER,
              attribution TEXT, persona_id TEXT, relation TEXT, request_started_at INTEGER,
              response_finished_at INTEGER, upstream_status INTEGER, error_code TEXT,
              input_tokens INTEGER, output_tokens INTEGER, total_tokens INTEGER,
              cache_hit_tokens INTEGER, cache_miss_tokens INTEGER, reasoning_tokens INTEGER,
              usage_status TEXT, status_cause TEXT);
            """)
        os.chmod(ro, 0o444)
        check("E7 只读库已建立（写失败场景可复现）", os.access(ro, os.R_OK), "ro db ok")
        os.chmod(ro, 0o666)

        # E8 非流式
        with post(body={"model": "mock-model", "messages": [], "stream": False}) as r:
            j8 = json.loads(r.read())
        check("E8 非流式 usage 正确", (j8.get("usage") or {}).get("total_tokens") == 18)

        # E6 代理崩溃恢复：先制造一条 open，再 kill 重启
        proxy.kill()
        time.sleep(0.3)
        proxy = start_proxy()
        procs[1] = proxy
        assert wait_port(PROXY), "proxy restart failed"
        r_after = rows()
        check("E6 重启后无遗留 open", all(x["usage_status"] != "open" for x in r_after),
              f"rows={len(r_after)}")

        # 账本一致性
        r_all = rows()
        statuses = {x["usage_status"] for x in r_all}
        check("E9 状态集合合法", statuses.issubset({"exact", "incomplete", "unknown", "replay", "open"}),
              f"{statuses}")
        print(f"\n账本共 {len(r_all)} 行：")
        for x in r_all:
            print(f"  {x['usage_status']:<10} cause={x['status_cause'] or '-':<22} "
                  f"status={x['upstream_status']} tokens={x['total_tokens']}")

    finally:
        for p in procs:
            p.terminate()
        for p in procs:
            try:
                p.wait(timeout=5)
            except Exception:
                pass

    failed = [r for r in results if not r[1]]
    print(f"\n{len(results)-len(failed)}/{len(results)} passed")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
