#!/usr/bin/env python3
"""R8-B PoC 测试：起 mock provider + 代理，跑 7 个场景并核对账本。

用法: python run_poc.py
输出: 每个场景 PASS/FAIL + 账本摘要；退出码 0 表示全部通过。
"""
from __future__ import annotations

import json
import os
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "ledger_test.db")
MOCK_PORT, PROXY_PORT = 7910, 7792

results: list[tuple[str, bool, str]] = []


def wait_port(port, timeout=10.0):
    t0 = time.time()
    while time.time() - t0 < timeout:
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", port)) == 0:
                return True
        time.sleep(0.05)
    return False


def post(path="/v1/chat/completions", body=None, headers=None, timeout=15):
    body = body or {"model": "mock-model", "messages": [{"role": "user", "content": "hi"}], "stream": True}
    req = urllib.request.Request(f"http://127.0.0.1:{PROXY_PORT}{path}",
                                 data=json.dumps(body).encode(), method="POST")
    req.add_header("Content-Type", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    return urllib.request.urlopen(req, timeout=timeout)


def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if detail else ""))


def ledger_rows():
    with sqlite3.connect(DB) as con:
        con.row_factory = sqlite3.Row
        return [dict(r) for r in con.execute("SELECT * FROM usage_requests ORDER BY request_started_at")]


def main():
    if os.path.exists(DB):
        os.remove(DB)
    py = sys.executable
    mock = subprocess.Popen([py, os.path.join(HERE, "mock_provider.py"), str(MOCK_PORT)],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    proxy = subprocess.Popen([py, os.path.join(HERE, "metering_proxy.py"), "--port", str(PROXY_PORT),
                              "--upstream", f"http://127.0.0.1:{MOCK_PORT}", "--db", DB],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert wait_port(MOCK_PORT) and wait_port(PROXY_PORT), "服务未就绪"

        # 1 普通流式
        with post() as r:
            data = r.read()
        check("1 流式透传包含 [DONE]", b"[DONE]" in data)
        check("1 流式内容完整", "一条 mock 回复".encode() in data)

        # 2 任意 chunk 边界（7 字节切，含 UTF-8 中间）
        with post(headers={"X-Mock-Mode": "chunk-split"}) as r:
            data2 = r.read()
        check("2 字节级切分后内容一致", data2 == data, f"{len(data2)}B vs {len(data)}B")

        # 3 CRLF + 注释帧
        with post(headers={"X-Mock-Mode": "crlf comment"}) as r:
            data3 = r.read()
        check("3 CRLF/注释帧可解析", b"[DONE]" in data3)

        # 4 非流式
        with post(body={"model": "mock-model", "messages": [], "stream": False}) as r:
            j = json.loads(r.read())
        check("4 非流式返回 usage", (j.get("usage") or {}).get("total_tokens") == 18)

        # 5 上游 500 透传
        try:
            with post(headers={"X-Mock-Mode": "error500"}) as r:
                r.read()
            code = 200
        except urllib.error.HTTPError as e:
            code = e.code
        check("5 上游 500 原样透传", code == 500, f"code={code}")

        # 6 客户端中途断开（用裸 socket 强制 RST，确保代理侧看到 BrokenPipe）
        import socket as _socket
        import struct as _struct
        s = _socket.create_connection(("127.0.0.1", PROXY_PORT))
        body = json.dumps({"model": "mock-model", "messages": [], "stream": True}).encode()
        s.sendall(
            b"POST /v1/chat/completions HTTP/1.1\r\nHost: 127.0.0.1\r\n"
            b"Content-Type: application/json\r\nX-Mock-Mode: slow\r\n"
            + f"Content-Length: {len(body)}\r\n\r\n".encode() + body
        )
        first = s.recv(64)          # 读一点就断开
        s.setsockopt(_socket.SOL_SOCKET, _socket.SO_LINGER, _struct.pack("ii", 1, 0))
        s.close()
        time.sleep(0.6)

        # 7 归因：带 persona header 与不带
        with post(headers={"X-SoulMate-Persona": "example_luna"}) as r:
            r.read()

        time.sleep(0.4)
        rows = ledger_rows()
        by_iid = rows
        exact = [r for r in by_iid if r["usage_status"] == "exact"]
        incomplete = [r for r in by_iid if r["usage_status"] == "incomplete"]
        unknown = [r for r in by_iid if r["usage_status"] == "unknown"]
        attributed = [r for r in by_iid if r["attribution"] == "persona"]
        unassigned = [r for r in by_iid if r["attribution"] == "unassigned"]

        check("6 断开记为 incomplete", len(incomplete) >= 1, f"incomplete={len(incomplete)}")
        check("7 有 persona 时归因正确", len(attributed) == 1 and attributed[0]["persona_id"] == "example_luna")
        check("7 无 persona 时记 unassigned", len(unassigned) >= 3, f"unassigned={len(unassigned)}")
        check("8 exact 行带 token", all(r["total_tokens"] == 18 for r in exact), f"exact={len(exact)}")
        check("9 上游 500 记 unknown", len(unknown) >= 1, f"unknown={len(unknown)}")

        print("\n账本摘要：")
        for r in by_iid:
            print(f"  {r['usage_status']:<11} attribution={r['attribution']:<10} "
                  f"tokens={r['total_tokens']} status={r['upstream_status']} cause={r['status_cause']}")

    finally:
        for p in (proxy, mock):
            p.terminate()
        try:
            proxy.wait(timeout=5)
            mock.wait(timeout=5)
        except Exception:
            pass

    failed = [r for r in results if not r[1]]
    print(f"\n{len(results) - len(failed)}/{len(results)} passed")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
