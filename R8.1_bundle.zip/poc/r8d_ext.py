#!/usr/bin/env python3
"""R8.1-P0-04：扩展真实 DeepSeek 验证。

覆盖：stream / non-stream / 长回复 / 缓存命中（同 prompt 两次）/ 无效 Key 401。
每条记录：客户端耗时、usage、账本行；结果写入 R8_D_EXT.json。
不给 usage 的情况不伪造 exact。
"""
from __future__ import annotations

import json
import os
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
R8 = os.path.dirname(HERE)
DB = os.path.join(HERE, "r8d_ext.db")
KEY_FILE = r"C:\Users\wslx\Desktop\deepseek_key.txt"
PROXY_PORT = 7797
UPSTREAM = "https://api.deepseek.com"
MODEL = "deepseek-flash"
LONG_PROMPT = ("请写一段大约三百字的中文说明，介绍什么是长时记忆，"
               "以及它和短期上下文窗口的区别。要求条理清楚。")


def wait_port(port, timeout=15):
    t0 = time.time()
    while time.time() - t0 < timeout:
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", port)) == 0:
                return True
        time.sleep(0.1)
    return False


def key_from_desktop():
    for line in open(KEY_FILE, encoding="utf-8"):
        if line.strip():
            return line.strip()
    return ""


def call(key, prompt, stream=True, max_tokens=256, tag=""):
    body = {"model": MODEL, "messages": [{"role": "user", "content": prompt}],
            "stream": stream, "max_tokens": max_tokens}
    if stream:
        body["stream_options"] = {"include_usage": True}
    req = urllib.request.Request(f"http://127.0.0.1:{PROXY_PORT}/v1/chat/completions",
                                 data=json.dumps(body).encode(), method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", "Bearer " + key)
    t0 = time.time()
    rec = {"tag": tag, "stream": stream, "max_tokens": max_tokens}
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            if stream:
                text, usage, events = [], None, 0
                for raw in r:
                    line = raw.decode("utf-8", "replace").strip()
                    if not line.startswith("data:"):
                        continue
                    payload = line[5:].strip()
                    if payload == "[DONE]":
                        continue
                    try:
                        obj = json.loads(payload)
                    except Exception:
                        continue
                    events += 1
                    if isinstance(obj.get("usage"), dict):
                        usage = obj["usage"]
                    for ch in obj.get("choices") or []:
                        d = ch.get("delta") or {}
                        if d.get("content"):
                            text.append(d["content"])
                rec.update({"status": 200, "events": events, "usage": usage,
                            "text_len": len("".join(text)), "head": "".join(text)[:60]})
            else:
                obj = json.loads(r.read())
                rec.update({"status": 200,
                            "usage": obj.get("usage"),
                            "text_len": len(obj["choices"][0]["message"]["content"] or ""),
                            "head": (obj["choices"][0]["message"]["content"] or "")[:60]})
    except urllib.error.HTTPError as e:
        rec.update({"status": e.code, "error_body": e.read()[:200].decode("utf-8", "replace")})
    except Exception as e:
        rec.update({"status": None, "error": f"{type(e).__name__}: {e}"})
    rec["elapsed_s"] = round(time.time() - t0, 2)
    print(json.dumps(rec, ensure_ascii=False), flush=True)
    return rec


def main():
    key = key_from_desktop()
    if not key:
        print("NO_KEY")
        return 2
    if os.path.exists(DB):
        os.remove(DB)
    proxy = subprocess.Popen([sys.executable, os.path.join(HERE, "metering_proxy.py"),
                              "--port", str(PROXY_PORT), "--upstream", UPSTREAM, "--db", DB],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        if not wait_port(PROXY_PORT):
            print("proxy 未就绪")
            return 1
        out = []
        out.append(call(key, "只回复两个字：收到", stream=True, max_tokens=128, tag="stream-short"))
        out.append(call(key, "只回复两个字：收到", stream=False, max_tokens=128, tag="nonstream-short"))
        out.append(call(key, LONG_PROMPT, stream=True, max_tokens=600, tag="stream-long"))
        # 缓存命中：同一长 prompt 再发一次
        out.append(call(key, LONG_PROMPT, stream=True, max_tokens=600, tag="stream-long-repeat"))
        # 无效 Key
        out.append(call("sk-invalid-" + "0" * 24, "hi", stream=True, max_tokens=16, tag="invalid-key"))
        time.sleep(0.5)
        with sqlite3.connect(DB) as con:
            con.row_factory = sqlite3.Row
            rows = [dict(r) for r in con.execute("SELECT * FROM usage_requests ORDER BY request_started_at")]
        print("\n账本行数:", len(rows))
        for r in rows:
            print(f"  {r['usage_status']:<10} status={r['upstream_status']} "
                  f"in={r['input_tokens']} out={r['output_tokens']} total={r['total_tokens']} "
                  f"cache_hit={r['cache_hit_tokens']} cache_miss={r['cache_miss_tokens']} "
                  f"reasoning={r['reasoning_tokens']}")
        result = {"model": MODEL, "calls": out, "ledger": rows}
        with open(os.path.join(R8, "R8_D_EXT.json"), "w", encoding="utf-8") as fh:
            json.dump(result, fh, ensure_ascii=False, indent=2)
        print("\nsaved R8_D_EXT.json")
        return 0
    finally:
        proxy.terminate()
        try:
            proxy.wait(timeout=8)
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
