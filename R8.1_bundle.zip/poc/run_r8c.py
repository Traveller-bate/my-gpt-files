#!/usr/bin/env python3
"""R8-C：真实 Shikigami（研究副本）→ 计量代理 → mock Provider 的兼容性验证。

不接触生产配置、不使用真实 Key、不联网。
用法: <venv-python> run_r8c.py
"""
from __future__ import annotations

import json
import os
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
R8 = os.path.dirname(HERE)
COPY = os.path.join(R8, "shikigami_copy")
DB = os.path.join(HERE, "r8c_ledger.db")
MOCK_PORT, PROXY_PORT, SHIKI_PORT = 7920, 7791, 7798
PY = sys.executable

PERSONAS = ["example_luna", "example_luna_en", "example_mochi", "example_mochi_en"]
results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if detail else ""), flush=True)


def wait_port(port, timeout=90.0):
    t0 = time.time()
    while time.time() - t0 < timeout:
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", port)) == 0:
                return True
        time.sleep(0.2)
    return False


def chat(persona: str, text: str, timeout=60):
    body = json.dumps({"message": text, "session_id": persona, "client_id": "r8c"}).encode()
    req = urllib.request.Request(f"http://127.0.0.1:{SHIKI_PORT}/chat", data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    t0 = time.time()
    got = []
    with urllib.request.urlopen(req, timeout=timeout) as r:
        for raw in r:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            try:
                obj = json.loads(line[5:].strip())
            except Exception:
                continue
            if obj.get("type") == "token" or obj.get("token"):
                got.append(obj.get("token") or obj.get("delta") or "")
            if obj.get("done"):
                break
    return "".join(got), time.time() - t0


def main():
    if os.path.exists(DB):
        os.remove(DB)
    procs = []
    try:
        procs.append(subprocess.Popen([PY, os.path.join(HERE, "mock_provider.py"), str(MOCK_PORT)],
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        procs.append(subprocess.Popen([PY, os.path.join(HERE, "metering_proxy.py"),
                                       "--port", str(PROXY_PORT),
                                       "--upstream", f"http://127.0.0.1:{MOCK_PORT}",
                                       "--db", DB],
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        if not (wait_port(MOCK_PORT) and wait_port(PROXY_PORT)):
            print("mock/proxy 未就绪")
            return 1

        env = dict(os.environ)
        env["PYTHONPATH"] = COPY
        env["SOULMATE_BIND_HOST"] = "127.0.0.1"
        env["SOULMATE_BIND_PORT"] = str(SHIKI_PORT)
        shiki = subprocess.Popen([PY, "-m", "uvicorn", "server:app",
                                  "--host", "127.0.0.1", "--port", str(SHIKI_PORT), "--loop", "asyncio"],
                                 cwd=COPY, env=env,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        procs.append(shiki)
        if not wait_port(SHIKI_PORT):
            print("Shikigami 副本未在 90s 内就绪")
            return 1
        print(f"Shikigami 副本已就绪 127.0.0.1:{SHIKI_PORT}", flush=True)

        texts = {}
        for p in PERSONAS:
            try:
                txt, dt = chat(p, "用一句话回答：现在几点？")
                texts[p] = txt
                print(f"  {p}: {dt:.2f}s len={len(txt)} text={txt[:40]!r}", flush=True)
            except Exception as e:
                print(f"  {p}: ERROR {type(e).__name__}: {e}", flush=True)

        # 一次非流式/工具型调用（用同一端点，Shikigami 内部选择 stream）
        time.sleep(0.5)
        with sqlite3.connect(DB) as con:
            con.row_factory = sqlite3.Row
            rows = [dict(r) for r in con.execute("SELECT * FROM usage_requests")]

        exact = [r for r in rows if r["usage_status"] == "exact"]
        check("1 四个 persona 全部返回内容", len([t for t in texts.values() if t]) == 4,
              f"ok={len([t for t in texts.values() if t])}")
        check("2 用量被代理记录", len(rows) >= 4, f"rows={len(rows)}")
        check("3 每条都有 exact usage", len(exact) >= 4, f"exact={len(exact)}")
        check("4 token 数来自 final chunk", all(r["total_tokens"] == 18 for r in exact), "total=18")
        check("5 归因为 unassigned（M2 预期）",
              all(r["attribution"] == "unassigned" for r in rows), f"{set(r['attribution'] for r in rows)}")
        check("6 模型名与 preset 一致", all(r["model"] in ("deepseek-flash", "mock-model") for r in rows),
              f"{set(r['model'] for r in rows)}")
        check("7 未产生 unknown/incomplete", len([r for r in rows if r["usage_status"] not in ("exact",)]) == 0,
              f"bad={len([r for r in rows if r['usage_status']!='exact'])}")

        print("\n账本：")
        for r in rows:
            print(f"  {r['usage_status']:<8} {r['attribution']:<10} model={r['model']} "
                  f"in={r['input_tokens']} out={r['output_tokens']} total={r['total_tokens']} "
                  f"status={r['upstream_status']}")
    finally:
        for p in procs:
            p.terminate()
        for p in procs:
            try:
                p.wait(timeout=8)
            except Exception:
                pass

    failed = [r for r in results if not r[1]]
    print(f"\n{len(results)-len(failed)}/{len(results)} passed")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
