#!/usr/bin/env python3
"""R8.1-P0-03：R8-C 的逐条对应（4 条用户消息 ↔ 7 次上游请求）。

做法：串行发送 4 条消息，每条记录起止时间；代理账本按时间窗归到消息，
输出 message_id → invocation_id 映射，并标注每条是主回复还是后台调用（按时间偏移）。
"""
from __future__ import annotations

import json
import os
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
R8 = os.path.dirname(HERE)
COPY = os.path.join(R8, "shikigami_copy")
DB = os.path.join(HERE, "r8c_map.db")
MOCK, PROXY, SHIKI = 7931, 7791, 7803
PERSONAS = ["example_luna", "example_luna_en", "example_mochi", "example_mochi_en"]


def wait_port(port, timeout=90):
    t0 = time.time()
    while time.time() - t0 < timeout:
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", port)) == 0:
                return True
        time.sleep(0.2)
    return False


def chat(persona, text):
    body = json.dumps({"message": text, "session_id": persona, "client_id": "r8c-map"}).encode()
    req = urllib.request.Request(f"http://127.0.0.1:{SHIKI}/chat", data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    out = []
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=90) as r:
        for raw in r:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            try:
                obj = json.loads(line[5:].strip())
            except Exception:
                continue
            if obj.get("token"):
                out.append(obj["token"])
            if obj.get("done"):
                break
    return "".join(out), t0, time.time()


def main():
    if os.path.exists(DB):
        os.remove(DB)
    procs = [subprocess.Popen([sys.executable, os.path.join(HERE, "mock_provider.py"), str(MOCK)],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)]
    procs.append(subprocess.Popen([sys.executable, os.path.join(HERE, "metering_proxy.py"),
                                   "--port", str(PROXY), "--upstream", f"http://127.0.0.1:{MOCK}",
                                   "--db", DB], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
    try:
        if not (wait_port(MOCK) and wait_port(PROXY)):
            print("mock/proxy 未就绪")
            return 1
        env = dict(os.environ)
        env["PYTHONPATH"] = COPY
        procs.append(subprocess.Popen([sys.executable, "-m", "uvicorn", "server:app",
                                       "--host", "127.0.0.1", "--port", str(SHIKI), "--loop", "asyncio"],
                                      cwd=COPY, env=env,
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        if not wait_port(SHIKI):
            print("Shikigami 未就绪")
            return 1

        windows = []
        for p in PERSONAS:
            txt, t0, t1 = chat(p, "用一句话回答：现在几点？")
            windows.append({"persona": p, "start": t0, "end": t1, "len": len(txt), "text": txt[:40]})
            print(f"  {p}: {t1-t0:.2f}s len={len(txt)}", flush=True)
            time.sleep(1.0)   # 留出后台调用落账时间

        time.sleep(1.5)
        with sqlite3.connect(DB) as con:
            con.row_factory = sqlite3.Row
            rows = [dict(r) for r in con.execute(
                "SELECT invocation_id, request_started_at, response_finished_at, attribution,"
                " usage_status, total_tokens, upstream_status, relation FROM usage_requests"
                " ORDER BY request_started_at")]

        mapping = []
        for w in windows:
            t0, t1 = w["start"], w["end"]
            primary = [r for r in rows if t0 - 0.5 <= r["request_started_at"] / 1000 <= t1 + 0.5]
            bg = [r for r in rows if t1 < r["request_started_at"] / 1000 <= t1 + 5.0]
            mapping.append({"persona": w["persona"], "primary": len(primary), "background": len(bg),
                            "invocations": [r["invocation_id"] for r in primary + bg]})

        print("\n消息 → 上游请求 映射：")
        for m in mapping:
            print(f"  {m['persona']:<18} primary={m['primary']} background={m['background']} "
                  f"invocations={len(m['invocations'])}")
        total = sum(m["primary"] + m["background"] for m in mapping)
        print(f"\n合计: 4 条消息 → {total} 次上游请求（账本 {len(rows)} 行）")

        out = {"personas": PERSONAS, "messages": mapping, "ledger_rows": rows,
               "total_upstream": total}
        with open(os.path.join(R8, "R8_C_MAPPING.json"), "w", encoding="utf-8") as fh:
            json.dump(out, fh, ensure_ascii=False, indent=2)
        print("saved R8_C_MAPPING.json")
    finally:
        for p in procs:
            p.terminate()
        for p in procs:
            try:
                p.wait(timeout=8)
            except Exception:
                pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
