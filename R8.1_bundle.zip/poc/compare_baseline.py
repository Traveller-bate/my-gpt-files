#!/usr/bin/env python3
"""P1-08：SoulMate 工作区基线核对。

规则：遍历 D:\\SoulMate 下所有文件，排除构建/缓存无关目录，输出 "sha256 相对路径" 清单。
用法:
  python compare_baseline.py manifest <out.txt>
  python compare_baseline.py compare <base.txt> <new.txt>
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

ROOT = Path(r"D:\SoulMate")
EXCLUDE_DIRS = {".git", "build", ".gradle", "node_modules", ".venv", "venv",
                "__pycache__", ".pytest_cache", ".idea", ".dsh-office-*"}


def iter_files():
    for p in ROOT.rglob("*"):
        if not p.is_file():
            continue
        parts = set(p.parts)
        if parts & EXCLUDE_DIRS:
            continue
        if any(part.startswith(".dsh-office-") for part in p.parts):
            continue
        yield p


def manifest(out_path: str):
    rows = []
    for p in sorted(iter_files()):
        try:
            h = hashlib.sha256(p.read_bytes()).hexdigest()
        except Exception:
            h = "UNREADABLE"
        rows.append(f"{h}  {p.relative_to(ROOT).as_posix()}")
    Path(out_path).write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(f"files={len(rows)} -> {out_path}")


def compare(base: str, new: str):
    a = Path(base).read_text(encoding="utf-8").splitlines()
    b = Path(new).read_text(encoding="utf-8").splitlines()
    sa, sb = set(a), set(b)
    only_a = sorted(sa - sb)
    only_b = sorted(sb - sa)
    print(f"base_entries={len(a)} new_entries={len(b)}")
    print(f"only_in_base={len(only_a)} only_in_new={len(only_b)}")
    for line in only_a[:20]:
        print("  -", line)
    for line in only_b[:20]:
        print("  +", line)
    same = len(sa & sb)
    print(f"identical_entries={same}")
    print("RESULT:", "NO_DIFF" if not only_a and not only_b else "DIFF_FOUND")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    cmd = sys.argv[1]
    if cmd == "manifest":
        manifest(sys.argv[2])
    elif cmd == "compare":
        compare(sys.argv[2], sys.argv[3])
    else:
        print(__doc__)
        sys.exit(2)
