#!/usr/bin/env python3
"""R8-D 受控真实 DeepSeek 验证（需手动提供 Key）。

Key 来源（按优先级）：
  1) 环境变量 DEEPSEEK_API_KEY
  2) 桌面文件 C:\\Users\\wslx\\Desktop\\deepseek_key.txt（首行，允许 sk- 前缀）

行为：
  - 起计量代理（--proxy-port 7795）→ 真实 https://api.deepseek.com
  - 发 1 次流式请求（max_tokens 很小，控制花费）
  - 打印并落盘 usage 字段、provider_request_id、账本行
  - 调用 /user/balance 打印余额（脱敏）
  - Key 只写入 Authorization，不打印、不入库、不进结果文件

用法: <venv-python> r8d_controlled.py [--model deepseek-flash]
"""
from __future__ import annotations

import argparse
import json
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
R8 = HERE.parent
DB = HERE / "r8d_ledger.db"
KEY_FILE = Path(r"C:\Users\wslx\Desktop\deepseek_key.txt")
RESULT = R8 / "R8_D_RESULT.json"

PROXY_PORT = 7795
UPSTREAM = "https://api.deepseek.com"


def load_key() -> str:
    env = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if env:
        return env
    if KEY_FILE.exists():
        for line in KEY_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if line.startswith("sk-") or len(line) > 20:
                return line
    return ""


def wait_port(port, timeout=15.0):
    t0 = time.time()
    while time.time() - t0 < timeout:
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", port)) == 0:
                return True
        time.sleep(0.1)
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="deepseek-flash")
    ap.add_argument("--max-tokens", type=int, default=16)
    args = ap.parse_args()

    key = load_key()
    if not key:
        print("NO_KEY: 未找到 Key（环境变量 DEEPSEEK_API_KEY 或桌面 deepseek_key.txt）")
        return 2

    if DB.exists():
        DB.unlink()
    proxy = subprocess.Popen([sys.executable, str(HERE / "metering_proxy.py"),
                              "--port", str(PROXY_PORT), "--upstream", UPSTREAM, "--db", str(DB)],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        if not wait_port(PROXY_PORT):
            print("代理未就绪")
            return 1

        body = {
            "model": args.model,
            "messages": [{"role": "user", "content": "只回复两个字：收到"}],
            "stream": True,
            "max_tokens": args.max_tokens,
            "stream_options": {"include_usage": True},
        }
        req = urllib.request.Request(f"http://127.0.0.1:{PROXY_PORT}/v1/chat/completions",
                                     data=json.dumps(body).encode(), method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", "Bearer " + key)
        req.add_header("Accept", "text/event-stream")

        text, events, usage = [], 0, None
        t0 = time.time()
        with urllib.request.urlopen(req, timeout=120) as r:
            for raw in r:
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if payload == "[DONE]":
                    continue
                try:
                    obj = json.loads(payload)
                except Exception:
                    continue
                events += 1
                if isinstance(obj.get("usage"), dict):
                    usage = obj["usage"]
                for ch in obj.get("choices") or []:
                    d = ch.get("delta") or {}
                    if d.get("content"):
                        text.append(d["content"])
        elapsed = round(time.time() - t0, 2)

        # 余额
        bal_req = urllib.request.Request(f"{UPSTREAM}/user/balance")
        bal_req.add_header("Authorization", "Bearer " + key)
        try:
            with urllib.request.urlopen(bal_req, timeout=20) as br:
                balance = json.loads(br.read())
        except Exception as e:
            balance = {"error": f"{type(e).__name__}: {e}"}

        out = {
            "model": args.model,
            "elapsed_s": elapsed,
            "events": events,
            "reply": "".join(text)[:100],
            "usage_raw": usage,
            "balance": balance,
        }
        RESULT.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(out, ensure_ascii=False, indent=2))

        # 账本行
        import sqlite3
        with sqlite3.connect(DB) as con:
            con.row_factory = sqlite3.Row
            rows = [dict(r) for r in con.execute("SELECT * FROM usage_requests")]
        print("\n账本：", json.dumps(rows, ensure_ascii=False, indent=2))

        ok = bool(usage) and usage.get("total_tokens") is not None
        print("\nRESULT:", "PASS final usage captured" if ok else "FAIL no final usage")
        return 0 if ok else 1
    finally:
        proxy.terminate()
        try:
            proxy.wait(timeout=8)
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
