# R8-B PoC 结果：计量代理 stub

日期：2026-11-21 22:5x（Asia/Shanghai）
环境：Windows 10 · Python 3.13（DSH 运行时）· 仅本机 loopback · 无真实 Key · 无外网
代码：`poc/mock_provider.py`、`poc/metering_proxy.py`、`poc/run_poc.py`

## 运行命令

```powershell
python D:\SoulMate_Research\R8\poc\run_poc.py
```

## 结果：11/11 通过

```
PASS 1 流式透传包含 [DONE]
PASS 1 流式内容完整
PASS 2 字节级切分后内容一致  [966B vs 966B]
PASS 3 CRLF/注释帧可解析
PASS 4 非流式返回 usage
PASS 5 上游 500 原样透传  [code=500]
PASS 6 断开记为 incomplete  [incomplete=1]
PASS 7 有 persona 时归因正确
PASS 7 无 persona 时记 unassigned  [unassigned=6]
PASS 8 exact 行带 token
PASS 9 上游 500 记 unknown

账本摘要：
  exact       attribution=unassigned tokens=18 status=200 cause=None
  exact       attribution=unassigned tokens=18 status=200 cause=None
  exact       attribution=unassigned tokens=18 status=200 cause=None
  exact       attribution=unassigned tokens=18 status=200 cause=None
  unknown     attribution=unassigned tokens=None status=500 cause=upstream_error
  incomplete  attribution=unassigned tokens=None status=200 cause=client_aborted
  exact       attribution=persona    tokens=18 status=200 cause=None
```

补充用例（单独执行）：

```
PASS 10 重启后 open -> unknown/proxy_restart
```

## 这些结果证明了什么

| 能力 | 证据 |
|---|---|
| 字节级透明 | 把 SSE 按 7 字节硬切（切在 UTF-8 中间）后，客户端收到的 966B 与完整流**完全一致** |
| 分帧兼容 | CRLF、注释帧 `:`、`[DONE]` 均可解析且不影响转发 |
| usage 捕获 | 流式最后一帧的 usage 被正确取出（prompt 11 / completion 7 / total 18，cache 3/8，reasoning 2） |
| 错误透传 | 上游 500 的状态码与 body 原样返回，同时记 `unknown/upstream_error` |
| 断开语义 | 客户端 RST 后记 `incomplete/client_aborted`，不伪造 token |
| 重启恢复 | 启动时把 `open` 行改成 `unknown/proxy_restart` |
| 归因边界 | 带 `X-SoulMate-Persona` 才归因；不带一律 `unassigned` |

## 这些结果**没有**证明什么

1. 没有接真实 Shikigami —— 因此"Shikigami 会不会传 persona"这个问题仍未解决（R8-A §1 的结论是：不会）。
2. 没有接真实 DeepSeek —— final usage 字段形状基于官方文档与 mock 构造，需一次受控真实调用确认。
3. 没有测并发与长连接压力；没有测代理自身内存/CPU。
4. 没有接入 launcher 的启动顺序与 fail-closed 逻辑（仅在设计里给出）。

## 与 R8-A 设计的关系

- P0-1 结论（单实例无归因）由本 PoC 反向印证：只有显式注入 header 才可能归因，而 Shikigami 没有注入点。
- P0-3 的 SSE 契约在本 PoC 中全部实现并通过。
- P1-4/P1-5 的字段与状态在审计表里落地（`usage_status` + `status_cause`）。
