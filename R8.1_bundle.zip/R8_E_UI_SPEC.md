# R8-E 用量页面设计规范（只设计，不实现）

适用版本：SoulMate R6 之后 · 手机 Termux 原生后端
前提：M2 归因方案（单实例 + `unassigned`），代理位于 Shikigami → Provider 之间

---

## 1. 信息架构

```
设置
└─ 模型与用量            ← 新增二级页
   ├─ 当前服务           Provider / 模型 / 后端状态 / 最后成功时间
   ├─ 账户余额           余额是否可用 + 多币种明细 + 查询时间
   ├─ 用量概览           今日 / 本月 / 累计（输入、输出、总计、本地估算费用）
   ├─ 角色拆分           暂不可用（M2），显示"未归因用量"分区与说明
   ├─ 最近请求           分页列表，含状态标签
   └─ 价格说明           价目版本 + 峰谷规则 + 免责声明
```

入口位置：设置页第一组（与"人格""模型"同级），不放主 Tab。

---

## 2. 页面线框

### 2.1 模型与用量（首页）

```
┌────────────────────────────────────┐
│ ← 模型与用量                        │
├────────────────────────────────────┤
│ 当前服务                            │
│   Provider      DeepSeek            │
│   模型          deepseek-flash      │
│   后端          ● 运行中  (已运行 3h12m)│
│   最后成功连接   20:41:07            │
├────────────────────────────────────┤
│ 账户余额              更新时间 20:40 │
│   ● 余额可用                        │
│   ¥ 12.34                           │
│     充值 ¥10.00 · 赠送 ¥2.34         │
│   「余额可用」表示余额足以继续调用，   │
│   不代表服务健康或 Key 有效           │
├────────────────────────────────────┤
│ 用量概览                            │
│   今日   in 12.3k  out 4.1k   ≈¥0.42│
│   本月   in 210k   out 88k    ≈¥3.12│
│   累计   in 1.2M   out 400k   ≈¥18.9│
│   本地估算，按价目 v2026-11 计算      │
├────────────────────────────────────┤
│ ◻ 角色拆分（当前不可用）              │
│   归因通道未建立，用量暂记入"未归因"。  │
│   查看说明 ›                          │
├────────────────────────────────────┤
│ 最近请求                    查看全部 ›│
│   20:41  deepseek-flash 18 tok  精确  │
│   20:40  deepseek-flash 42 tok  精确  │
│   20:39  deepseek-flash -       未知  │
└────────────────────────────────────┘
```

### 2.2 最近请求（列表页）

每行：
```
时间 · 模型 · 输入/输出 · 状态标签 · 估算费用
```
点击展开：
```
┌ 请求详情 ────────────────────────┐
│ 时间      2026-11-21 20:41:07     │
│ 模型      deepseek-flash          │
│ 输入      11 tokens（缓存命中 3）  │
│ 输出      7 tokens（推理 2）       │
│ 总计      18 tokens               │
│ 状态      精确                     │
│ 关系      主回复                   │
│ 费用      ¥0.00012（v2026-11 平峰）│
│ 请求 ID   chatcmpl-****（脱敏）     │
└──────────────────────────────────┘
```
不显示：请求正文、系统提示词、完整 Authorization、Key。

---

## 3. 状态矩阵（必须全部实现）

| 状态 | 触发 | 展示 | 文案 |
|---|---|---|---|
| 加载中 | 首次请求 | 骨架占位 | — |
| 空数据 | 区间内无记录 | 空状态插图 + 按钮"切换区间" | 该时间段暂无用量记录 |
| 余额过期 | 超过 5 分钟未刷新 | 值后加 `· 已过期` 淡色 | — |
| 余额查询失败 | 网络/上游错误 | **显示 last-known 值** + 警示条 | 余额查询失败，显示 20:35 的数据 |
| 余额不可用 | `is_available=false` | 红色标记 | 账户余额不足以继续调用 |
| 未归因 | `attribution=unassigned` | 单独分区，不混入角色 | 当前未建立角色归因，用量统一记入未归因 |
| 用量不完整 | `usage_status=incomplete` | 黄色标签 | 该次请求未收到完整用量，可能少计 |
| 用量未知 | `usage_status=unknown` | 灰色标签 | 未取得用量 |
| 重放 | `usage_status=replay` | 蓝色标签 | 幂等重放，未产生新请求 |
| 后端离线 | health 失败 | 顶部横幅 | 后端不可用，显示的是最后一次数据 |

**禁止**：任何状态下把未知/不完整的用量显示为 0 或估算补齐。

---

## 4. API 契约

### 4.1 `GET /v1/usage/summary`

```
?from=2026-11-01&to=2026-11-21&groupBy=day|persona|provider|model
→ 200
{
  "from": "2026-11-01", "to": "2026-11-21",
  "currency": "CNY",
  "priceVersion": "2026-11",
  "totals": {"input": 210345, "output": 88012, "total": 298357,
             "estimatedCost": 3.12, "requests": 142,
             "incomplete": 2, "unknown": 1},
  "groups": [
    {"key": "unassigned", "input": 210345, "output": 88012, "total": 298357,
     "estimatedCost": 3.12, "requests": 142}
  ],
  "attributionAvailable": false
}
```
- `attributionAvailable=false` 时前端必须显示"未归因"分区，不得把 groups 里的 key 当作角色名。

### 4.2 `GET /v1/usage/requests`

```
?page=1&pageSize=20&status=exact|incomplete|unknown|replay&from=&to=
→ 200
{
  "page": 1, "pageSize": 20, "total": 142,
  "items": [{
    "id": "uuid", "at": "2026-11-21T20:41:07+08:00",
    "model": "deepseek-flash", "provider": "deepseek",
    "input": 11, "output": 7, "total": 18,
    "cacheHit": 3, "cacheMiss": 8, "reasoning": 2,
    "status": "exact", "relation": "primary",
    "attribution": "unassigned", "personaId": null,
    "estimatedCost": 0.00012, "currency": "CNY", "priceVersion": "2026-11",
    "providerRequestId": "chatcmpl-****"
  }]
}
```

### 4.3 `GET /v1/usage/balance`

```
→ 200
{
  "isAvailable": true,
  "isAvailableMeaning": "余额是否足以继续调用 API，不代表服务健康或 Key 有效",
  "checkedAt": "2026-11-21T20:41:07+08:00",
  "stale": false,
  "balanceInfos": [
    {"currency": "CNY", "totalBalance": "12.34",
     "grantedBalance": "2.34", "toppedUpBalance": "10.00"}
  ],
  "lastKnown": null,
  "error": null
}
→ 502（上游失败）
{ "isAvailable": null, "stale": true, "checkedAt": null,
  "lastKnown": {"checkedAt": "2026-11-21T20:35:00+08:00",
                "balanceInfos": [{"currency":"CNY","totalBalance":"12.34",
                                  "grantedBalance":"2.34","toppedUpBalance":"10.00"}]},
  "error": {"code": "BALANCE_UPSTREAM_ERROR", "message": "余额查询失败", "retryable": true} }
```

### 4.4 `GET /v1/usage/pricing`

```
→ 200
{
  "version": "2026-11", "currency": "CNY", "updatedAt": "2026-11-01T00:00:00+08:00",
  "models": [
    {"model": "deepseek-flash",
     "tiers": [
       {"tier": "off_peak", "cacheHitPer1M": 0.5, "cacheMissPer1M": 2.0, "outputPer1M": 3.0,
        "effectiveFrom": "2026-11-01T00:00:00+08:00", "effectiveTo": null},
       {"tier": "peak",     "cacheHitPer1M": 0.6, "cacheMissPer1M": 2.4, "outputPer1M": 3.6,
        "window": "UTC 工作日 00:30-08:30 除外"}
     ]}
  ],
  "disclaimer": "本地估算费用，非 DeepSeek 官方账单"
}
```

### 4.5 错误码表

| code | HTTP | 含义 | 前端动作 |
|---|---|---|---|
| USAGE_EMPTY | 200 | 无记录 | 空状态 |
| USAGE_KEY_MISSING | 401 | 服务端未配 Key | 提示配置，禁用余额模块 |
| BALANCE_UPSTREAM_ERROR | 502 | 余额上游失败 | 显示 last-known + 警示 |
| USAGE_DB_LOCKED | 503 | 账本忙 | 重试一次后提示 |

---

## 5. 交互细节

1. 下拉刷新：只刷新余额 + 首页汇总；请求明细按需加载。
2. 区间切换：今日 / 本月 / 累计 / 自定义（最大 90 天）。
3. 费用展示：≥0.01 保留两位；<0.01 显示 `¥0.00`，hover/点击显示精确到 6 位。
4. 多币种：账户若返回多种货币，按数组顺序全部展示，不合并。
5. 无网络：顶部横幅 + 保留缓存数据，不显示空状态。
6. 隐私：任何页面不得出现 Key、Authorization、请求正文；`providerRequestId` 只显示后 4 位。

---

## 6. 与后端的关系（依赖顺序）

```
launcher: metering(7791) → shikigami(7788) → gateway(7790)
Gateway /v1/usage/* 读的是 metering 的 SQLite 账本（只读连接）
余额由 Gateway 直连 DeepSeek（服务端持有 key），不经过代理
```
metering 未就绪时 Gateway 的 `/v1/usage/*` 返回 `USAGE_UNAVAILABLE`，App 显示后端离线横幅。

---

## 7. 验收清单（设计阶段）

- [x] 余额与用量分区展示
- [x] `is_available` 文案不夸大
- [x] 多币种支持
- [x] 未归因分区（M2）
- [x] incomplete/unknown/replay 三态可见
- [x] 余额失败保留 last-known
- [x] 估算费用标注版本与免责声明
- [x] 无 Key / 无正文 / 无 Authorization
