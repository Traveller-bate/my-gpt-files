# R8-D 结果：受控真实 DeepSeek 调用

日期：2026-11-21 23:09（Asia/Shanghai）
方式：代理 `127.0.0.1:7795` → `https://api.deepseek.com`，一次流式请求（`max_tokens=16`），
Key 取自桌面文件，只写入 `Authorization`，未打印、未入库。

## 结果：PASS

```json
{
  "model": "deepseek-flash",
  "elapsed_s": 1.28,
  "events": 18,
  "reply": "",
  "usage_raw": {
    "prompt_tokens": 35,
    "completion_tokens": 16,
    "total_tokens": 51,
    "prompt_tokens_details": {"cached_tokens": 0},
    "completion_tokens_details": {"reasoning_tokens": 16},
    "prompt_cache_hit_tokens": 0,
    "prompt_cache_miss_tokens": 35
  },
  "balance": {
    "is_available": true,
    "balance_infos": [
      {"currency": "CNY", "total_balance": "8.22", "granted_balance": "0.00", "topped_up_balance": "8.22"}
    ]
  }
}
```

账本行（`usage_status=exact`）：

```
provider=mock  model=deepseek-flash  endpoint=/v1/chat/completions  stream=1
attribution=unassigned  relation=primary
input=35  output=16  total=51  cache_hit=0  cache_miss=35  reasoning=16
upstream_status=200
```

## 四个确认

### 1. final usage 确实在 `[DONE]` 前返回
18 个事件，最后一个 data 帧带完整 usage。代理解析到的字段与官方文档一致。

### 2. 缓存字段存在两种写法
同时出现 `prompt_cache_hit_tokens` / `prompt_cache_miss_tokens` 与 `prompt_tokens_details.cached_tokens`。
实现时应**优先取前者**，后者作为校验；两者冲突时记 `unknown` 而不是择一。

### 3. 余额接口形状与设计一致
`is_available` + `balance_infos[]`（currency/total/granted/topped_up），当前余额 ¥8.22，全部为充值余额。

### 4. `deepseek-flash` 是推理模型，`max_tokens` 会被推理吃光
本次 `max_tokens=16`，`reasoning_tokens=16`，`reply` 为空——输出配额全被推理占用，没有正文。

**产品含义**：用量统计不受影响（usage 照常返回），但**对话必须给足 `max_tokens`**（建议 ≥ 1024），
否则用户会看到"空回复"。这解释了此前某些极短回复的成因。

## 发现的一个实现缺陷（待修）

代理账本的 `provider` 字段被**硬编码为 `mock`**（`metering_proxy.py` 的 `provider="mock"`）。
真实调用时该字段应为 `deepseek`。R8-D 的账本因此显示 `provider=mock model=deepseek-flash`，
属于 stub 的已知瑕疵，接入生产前必须改为从配置注入。

## 成本

单次请求：输入 35 tokens + 输出 16 tokens ≈ ¥0.0002 量级（按当前价目）。余额从查询结果看为 ¥8.22。

## 局限

1. 只做了一次短请求，未覆盖长回复、多轮、工具调用。
2. 未验证 `include_usage` 在 `stream_options` 与默认两种形态下的差异（本次显式写了 `include_usage: true`）。
3. 未测试 DeepSeek 4xx/5xx 时的 usage 缺失分支（已在 mock 中覆盖，真实分支未测）。
4. 余额只查了一次，未验证多币种场景。
