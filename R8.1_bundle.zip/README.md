# R8.1 补证交付说明（README）

本包针对《SoulMate_R8阶段报告独立复审与R8.1补证整改任务书》逐项补证。
**不含任何 API Key 明文**；所有密钥只以 SHA-256 前 12 位指纹出现。

## 目录

```
R8.1_bundle.zip
├── README.md                  ← 本文件
├── R8_A_DESIGN.md             设计补正（归因/凭证/SSE/账本/价格/launcher）
├── R8_C_RESULTS.md            真实 Shikigami 兼容（含三轮调用数波动）
├── R8_D_RESULTS.md            首次真实 DeepSeek 记录
├── R8_D_EXT.json              扩展真实调用原始结果（5 次）
├── R8_C_MAPPING.json          4 条消息 → 上游请求的逐条账本
├── R8_E_UI_SPEC.md            用量页面规范与 API 契约
├── POC_RESULTS.md             Mock PoC 结果
├── R8_1_REPORT.md             本轮补证说明与结论
├── evidence/
│   ├── poc_base.log           run_poc.py 原始输出（11/11）
│   ├── poc_ext.log            run_poc_ext.py 原始输出（12/12）
│   ├── r8c.log                run_r8c.py 原始输出（7/7）
│   ├── r8c_map.log            run_r8c_map2.py 原始输出
│   ├── manifest_baseline_recomputed.txt  工作区基线（14121 文件）
│   ├── manifest_r8.txt                    当前工作区（同一规则）
│   ├── baseline_compare.txt               比对输出（NO_DIFF）
│   └── key_security.md                    密钥安全核验（脱敏）
├── poc/
│   ├── mock_provider.py       mock Provider（支持 chunk-split/CRLF/注释帧/错误码/no-usage）
│   ├── metering_proxy.py      计量代理（字节级透传 + usage + 账本）
│   ├── run_poc.py             基础 11 用例
│   ├── run_poc_ext.py         扩展 12 用例
│   ├── run_r8c.py             真实 Shikigami 副本 7 项
│   ├── run_r8c_map2.py        4 条消息 → 上游请求映射
│   ├── r8d_controlled.py      单次受控真实调用
│   ├── r8d_ext.py             扩展真实调用（5 次）
│   ├── compare_baseline.py    工作区清单生成与比对
│   ├── env_fingerprint.py     进程环境指纹（手机端）
│   └── keyfiles_fp.py         .env 指纹（手机端）
└── SHA256SUMS.txt
```

## 复现命令（干净目录解压后）

```powershell
$py = "D:\SoulMate\runtime\venv\Scripts\python.exe"

# 1. 基础 PoC（11 用例，纯本地 mock）
& $py poc\run_poc.py

# 2. 扩展 PoC（12 用例：随机切片/慢客户端/取消/401/402/429/500/no-usage/重启）
& $py poc\run_poc_ext.py

# 3. 真实 Shikigami 副本兼容（需研究副本目录）
& $py poc\run_r8c.py

# 4. 工作区基线核对
& $py poc\compare_baseline.py manifest evidence\manifest_now.txt
& $py poc\compare_baseline.py compare evidence\manifest_baseline_recomputed.txt evidence\manifest_now.txt
```

真实 DeepSeek 的两支脚本（`r8d_controlled.py` / `r8d_ext.py`）需要 Key：
从 `C:\Users\wslx\Desktop\deepseek_key.txt` 或环境变量 `DEEPSEEK_API_KEY` 读取；无 Key 时返回 `NO_KEY` 并退出，不会发出请求。

## 未包含

- 三个社区仓库源码（体积大、且已按 commit 锁定，见 R7 交付）
- Shikigami 研究副本（20.8 MB；用 `runtime/shikigami` 复制并改 `config/app.yaml` 的 `base_url` 即可复现）
- 手机端数据（R8 全部在桌面完成）
