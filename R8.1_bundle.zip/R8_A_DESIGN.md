# R8-A 设计补正：计量代理解耦、归因通道与账本规范

依据：《SoulMate_R7研究交付独立复审与R8技术验证任务书》P0-1 / P0-2 / P0-3 / P1-4~8 / P2-9
性质：**设计文档**。不修改产品源码，不接生产 launcher，不替换 app.yaml。

---

## 0. 结论摘要

| 项 | 结论 |
|---|---|
| P0-1 persona 归因 | **单实例拓扑下无法可靠归因**。证据：`chat.py:91` 取全局 active preset；`ChatRequest`（`chat.py:30-37`）无 model/preset 字段；provider 请求体经白名单过滤（`model_gateway.py:89-96`）；无 header 注入点（`openai_compat.py:36-42` 只传 api_key/base_url/timeout） |
| 可行方案 | M1 每 persona 独立实例（可归因，资源 ×4）／M2 单实例记 `unassigned`（诚实但无角色拆分）／M3 向上游提 PR 加 per-session header（长期） |
| 推荐 | v1 采用 **M2**（不伪造角色拆分，UI 明确"未归因"），需要角色维度时再评估 M1；M3 作为上游建议 |
| P0-2 Key | Shikigami 用 `server.py:95` `load_dotenv()` 把 .env 灌进进程环境；请求头由 `model_gateway.py:103` 写入 `Authorization: Bearer <key>`。代理**转发该头**即可，无需第二份密钥 |
| P0-3 端点 | OpenAI-compatible 只有 `/v1/chat/completions`（stream / non-stream 两种）；另有 Gemini native `/v1beta/models/<m>:streamGenerateContent` 分支。后台调用共用同一 client |
| 账本 | 增加 invocation_id / parent_invocation_id / task_id / fingerprint / status_cause；状态四态 |
| 余额 | DTO 改 `balance_infos[]` 多币种；`is_available` 文案纠正 |
| 价格 | 引入 tier（peak/off-peak）+ 时区 + 规则版本；历史不重算 |

---

## 1. P0-1：persona / relation 归因通道（核心缺口）

### 1.1 为什么"改 base_url 就够了"不成立

代理位于 **Shikigami → Provider** 之间，看到的是 Shikigami 发的请求。它同时看不到：
- Gateway 的入站请求（personaId、clientMessageId）；
- Shikigami 的 session/profile 上下文。

代码级证据：
| 事实 | 位置 |
|---|---|
| 聊天请求体只有 message/client_id/request_id/session_id 等，无 model/preset | `src/api/chat.py:30-37` |
| preset 取自**全局** `config.get_active_llm_preset()` | `src/api/chat.py:91` |
| 路由目标由 preset 的 base_url 静态拼出 | `src/agent/model_gateway.py:11-34` |
| 请求体只透传白名单键 + preset 的 `extra_body` | `src/agent/model_gateway.py:89-96` |
| HTTP 头只有 Content-Type 与 Authorization，无自定义头注入点 | `src/agent/model_gateway.py:100-104` |
| OpenAI 客户端构造只接收 api_key/base_url/timeout | `src/llm/openai_compat.py:36-42` |

结论：**没有任何"请求级"字段能从 Shikigami 传到 Provider 而不改源码**。`extra_body` 是 preset 级静态值，最多能标记"哪个 preset"，不能标记"哪个 persona"（四个 persona 共用同一 preset）。

### 1.2 四个备选方案

| 方案 | 机制 | 能归因 | 代价 | 风险 |
|---|---|---|---|---|
| **M1 每 persona 独立实例** | 4 个 Shikigami 进程，各自配置目录，`default_llm` 指向不同 preset（不同代理端口 7791-7794）；Gateway 按 persona 路由 | 是（按端口） | 内存 ×4、端口 ×4、运维复杂 | 手机内存紧张；后台调用也需路由 |
| **M2 单实例 + unassigned** | 单实例不变；账本所有行 `persona_id = NULL`，`attribution = unassigned` | 否 | 无 | UI 不能按角色拆分（但诚实） |
| **M3 上游 PR** | 向 Shikigami 提交可选特性：把 `session.profile_id` 写入 provider 请求头 `X-SoulMate-Persona` | 是 | 需上游接受 | 时间不可控；当前版本不可用 |
| M4 preset 静态标记 | `extra_body` 加固定字段 | 否（只区分 preset） | 无 | 无法区分 persona，等同 M2 |

### 1.3 推荐与验收

- **v1（本次）**：M2。账本显式 `attribution='unassigned'`，UI 提供"未归因用量"分区，总额与总额拆分不伪造。
- **需要角色维度时**：评估 M1（见 §1.4 的落地要点）。
- **长期**：M3，作为上游贡献提案，不在本轮实施。

### 1.4 M1 落地要点（若将来采用）
1. 每个实例独立 `config/app.yaml`：`default_llm` 指向 `Persona-X` preset，其 `base_url=http://127.0.0.1:779<X>/v1`。
2. 每个实例独立 data 目录与端口（7788-7791）。
3. Gateway 的 `persona → 实例端口` 映射表放在 Gateway 配置，不走 Shikigami。
4. 后台调用（emotion/affinity/memory）在同一实例内发起，因此自然归到该 persona。
5. 代价：4 × Python 进程；需实测手机内存。

---

## 2. P0-2：代理如何拿凭证

证据链：
- `runtime/shikigami/server.py:95-96`：`load_dotenv()` 把 `.env` 灌入 `os.environ`。
- `src/config/app_config.py:61-67`：preset 的 `api_key` 从 `os.environ[<PRESET>_API_KEY]` 注入。
- `src/agent/model_gateway.py:100-104`：请求头 `Authorization: Bearer <key>`。

两种取法：
| 方案 | 做法 | 优点 | 缺点 |
|---|---|---|---|
| **A 透传（推荐）** | 代理把收到的 `Authorization` 原样转发给上游；自己不做凭证管理 | 零密钥复制；换 key 无需改代理 | 代理必须保证日志/异常不回显该头 |
| B 自持 | 代理进程从 `.env` 读同一个 key（launcher 注入环境） | 可独立调用余额接口 | 多一处读取点，需保证权限与环境一致 |

推荐 A + 余额接口由 **Gateway** 调用（Gateway 已能读环境，或由 launcher 注入 `DEEPSEEK_API_KEY`）。
硬规则：任何日志、错误页、trace 都不得出现 `Authorization`、请求体、明文 Key（`model_gateway.py` 已有"错误体可能回显凭证"的同类防护，代理需照做）。

---

## 3. P0-3：端点清单与 SSE 透明性

实际路径（源码确认）：
| API | 端点 | 模式 | 说明 |
|---|---|---|---|
| OpenAI-compatible | `POST {base_url}/chat/completions` | stream=true / false | 主路径；DeepSeek 走这里 |
| Gemini native | `POST /v1beta/models/<model>:streamGenerateContent` | stream | 仅当 preset 为 gemini 原生 |

调用方：`stream_chat()`（`openai_compat.py:83-113`）与 `chat()`（`:115-140`）以及后备 `[LLM Error]` 文本。
后台调用（情绪/亲密/记忆/摘要）复用同一 provider 与同一 base_url，因此**都经过代理**。

SSE 透明性要求（代理实现契约）：
1. 按字节解析，不假设 chunk 边界；保留原始字节顺序，不重排、不合并、不延迟。
2. 支持 CRLF / LF、注释帧 `:`、空行分帧、`[DONE]`、`data:` 前置空格。
3. UTF-8 可能被切在 chunk 中间 → 用增量解码器，不能 `decode()` 整块。
4. 捕获最后一个含 `usage` 的 data 行（DeepSeek 在 `[DONE]` 前）。
5. 上游 4xx/5xx：原样透传状态码与 body，同时记 `upstream_status`。
6. 客户端断开：停止转发；已产生上游消耗仍要落账（`incomplete`）。
7. 代理重启：未终结记录置 `unknown`。

---

## 4. P1-4：账本字段 v2

```sql
CREATE TABLE usage_requests (
  id                    INTEGER PRIMARY KEY,
  invocation_id         TEXT NOT NULL,          -- 本代理生成的调用 ID
  parent_invocation_id  TEXT,                   -- 重试/重放指向原调用
  task_id               TEXT,                   -- 后台任务（emotion/affinity/memory/summary）
  relation              TEXT NOT NULL,          -- primary/retry/fallback/background:*/unassigned
  attribution           TEXT NOT NULL,          -- persona|unassigned|service
  persona_id            TEXT,                   -- 仅当 attribution=persona
  conversation_id       TEXT,
  client_message_id     TEXT,
  provider              TEXT NOT NULL,
  account_alias         TEXT,
  key_fingerprint       TEXT,
  model                 TEXT,
  endpoint              TEXT,                   -- /v1/chat/completions 等
  stream                INTEGER,
  request_fingerprint   TEXT,                   -- sha256(去敏 body 结构)
  request_started_at    INTEGER,
  response_finished_at  INTEGER,
  upstream_status       INTEGER,
  error_code            TEXT,
  input_tokens          INTEGER,
  output_tokens         INTEGER,
  total_tokens          INTEGER,
  cache_hit_tokens      INTEGER,
  cache_miss_tokens     INTEGER,
  reasoning_tokens      INTEGER,
  usage_status          TEXT NOT NULL,          -- exact|incomplete|unknown|replay
  status_cause          TEXT,                   -- no_final_usage|client_aborted|proxy_restart|upstream_error|idempotent_replay
  price_version         TEXT,
  price_tier            TEXT,                   -- peak|off_peak
  estimated_cost        REAL,
  currency              TEXT
);
```
索引：`(response_finished_at)`、`(persona_id, response_finished_at)`、`(provider, model, response_finished_at)`、`(invocation_id)`、`(provider_request_id)`。

禁止字段：请求正文、系统提示词、Authorization、明文 Key。

---

## 5. P1-5：四态定义

| 状态 | 触发 | 是否计入 token 汇总 | UI |
|---|---|---|---|
| exact | 收到并校验 final usage | 是 | 精确 |
| incomplete | 客户端断开 / 流被截断但上游已产生消耗；无 final usage | 仅在能确认的字段上记，缺失字段 NULL | 不完整（可能少计） |
| unknown | 上游错误无 usage / 代理崩溃重启后发现未终结 | 否 | 未知 |
| replay | Gateway 幂等命中缓存，未产生新的上游请求 | 否（展示历史那次） | 重放 |

硬规则：不得按字符数估算 token 或费用；`estimated_cost` 只在 `usage_status=exact` 时计算。

---

## 6. P1-6：余额 DTO（多币种）

```json
{
  "isAvailable": true,
  "isAvailableMeaning": "余额是否足以继续调用 API，不代表服务健康或 Key 有效",
  "balanceInfos": [
    {"currency": "CNY", "totalBalance": "12.34", "grantedBalance": "2.34", "toppedUpBalance": "10.00"}
  ],
  "checkedAt": "2026-11-21T22:40:00+08:00",
  "stale": false,
  "lastKnown": {"checkedAt": "...", "balanceInfos": [...]},
  "error": null
}
```
失败时保留 `lastKnown` 并置 `stale=true`，**不得显示 0**。

---

## 7. P1-7：峰谷价格模型

```sql
CREATE TABLE price_rules (
  version      TEXT,          -- 如 2026-11-01
  model        TEXT,
  tier         TEXT,          -- peak | off_peak
  currency     TEXT,
  cache_hit_per_1m   REAL,
  cache_miss_per_1m  REAL,
  output_per_1m      REAL,
  effective_from INTEGER,
  effective_to   INTEGER,
  tz_rule        TEXT,        -- 时区 + 工作日 + 时间窗 + 节假日表
  rule_version   TEXT
);
```
- 每次请求记录 `price_version` + `price_tier`（按请求**开始时间**落在哪个档）。
- 价目更新只影响新请求；历史行不重算。
- UI 统一标"本地估算费用（按 <version> 价目）"，不称官方账单。

---

## 8. P1-8：final usage 兼容性

- DeepSeek 文档：流式在 `[DONE]` 前最后一个 chunk 携带整次请求 usage；`include_usage=true` 时前面 chunk 的 usage 为 null。
- 代理必须：①按 `include_usage` 行为兼容两种形态；②解析 `prompt_cache_hit_tokens` / `prompt_cache_miss_tokens` / `completion_tokens_details.reasoning_tokens`；③字段缺失记 `unknown`，不自补。
- 验证手段：mock 流（覆盖 4 种分帧）→ 受控真实调用 1 次 → 核对账本与官方 usage 一致。

---

## 9. P2-9：launcher 与故障处理

现状（`runtime/launcher.py:30-48`）：SPEC 里只有 shikigami 与 gateway 两项，各自有 port/health/pidfile/log/env。
新增 `metering` 服务需要：
1. **启动顺序**：metering 先于 shikigami（否则 Shikigami 首次请求会失败）。launcher 需支持依赖声明。
2. **就绪检查**：`GET /healthz` 返回 200 且包含 `{"ready":true}`。
3. **崩溃策略**：launcher 监控 PID + 健康探测，异常时重启；连续失败则**拒绝启动 Shikigami**（fail-closed），不得静默直连上游。
4. **超时/日志**：代理日志轮转，禁止写 Authorization/正文。
5. **监听**：只绑 `127.0.0.1`（与现状一致）。

---

## 10. stub PoC 结果

见 `poc/` 与 `POC_RESULTS.md`：mock provider + 计量代理，验证了字节级 SSE 透明、usage 捕获、错误透传、客户端断开与重启恢复；**未接生产配置、未用真实 Key**。
